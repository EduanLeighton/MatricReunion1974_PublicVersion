using Microsoft.Extensions.Configuration;
using MatricReunion1974.Components;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);


// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents()
    .AddInteractiveWebAssemblyComponents();

var app = builder.Build();


// Get root path:
string assemblyLocation = Assembly.GetExecutingAssembly().Location;

string assemblyDirectory = Path.GetDirectoryName(assemblyLocation);

string jsonFilePath = Path.Combine(assemblyDirectory, "matricreunion1974-firebase-adminsdk-6xa6i-3b69a7d70b.json");


Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", jsonFilePath);

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseWebAssemblyDebugging();
}
else
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode()
    .AddInteractiveWebAssemblyRenderMode()
    .AddAdditionalAssemblies(typeof(MatricReunion1974.Client._Imports).Assembly);

app.Run();
