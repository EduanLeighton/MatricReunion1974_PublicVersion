window.downloadFile = function (filename, content) {
    var link = document.createElement('a');
    link.setAttribute('href', 'data:text/csv;charset=utf-8;base64,' + content);
    link.setAttribute('download', filename);
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};